import EN from "./en-icon.svg";
import LogoPitel from "./logo-pitel.svg";
import ZOA from "./oa-icon.svg";
import VI from "./vi-icon.svg";
export { EN, LogoPitel, VI, ZOA };
