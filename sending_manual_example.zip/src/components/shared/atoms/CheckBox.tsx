import React from 'react';

const CheckBox = () => {
  return (
    <div>
      <h1>CheckBox</h1>
    </div>
  );
};

export default CheckBox;