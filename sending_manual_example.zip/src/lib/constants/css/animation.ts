export const KEYFRAMES = {
	"sidebar-animation": {
		"0%": { opacity: "0", left: "-100%" },
		"100%": { opacity: "1", left: "0%" },
	},
};
