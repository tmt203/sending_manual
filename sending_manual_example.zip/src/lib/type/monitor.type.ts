export type CampaignMonitor = {
	total: number;
	total_done: number;
	total_paused: number;
	total_running: number;
};
